import configparser
import json
import logging
import logging.config
import os

from src.git.api import GitHubOps

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# --- Logging -----------------------------------------------------------------
# Lambda ships logs to CloudWatch automatically, so no FileHandler is needed.
# (The Lambda filesystem is read-only except /tmp.)
logger_conf = os.path.join(BASE_DIR, "logger.conf")
if os.path.exists(logger_conf):
    logging.config.fileConfig(logger_conf, disable_existing_loggers=False)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# --- Config (loaded once per cold start) ---------------------------------------
config = configparser.ConfigParser()
config.read(os.path.join(BASE_DIR, "app.conf"))

git_config = configparser.ConfigParser()
git_config.read(os.path.join(BASE_DIR, "git.conf"))


def _load_token():
    """GitHub token: GIT_FINE_GRAIN_TOKEN env var, or JSON secret SECRET_NAME with key git_fine_grain_token.
    Falls back to git.conf only if neither is set (don't commit a real token there)."""
    token = os.getenv("GIT_FINE_GRAIN_TOKEN")
    name = os.getenv("SECRET_NAME")
    if not token and name:
        import boto3
        secret = boto3.client("secretsmanager").get_secret_value(SecretId=name)["SecretString"]
        token = json.loads(secret).get("git_fine_grain_token")
    if token:
        git_config.set("Settings", "git_fine_grain_token", token)


_load_token()
GitHubOps.initialize(git_config)


def _response(status_code, message):
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"message": message}),
    }


def _extract_params(event):
    """Support direct invocation, API Gateway (JSON body / query string), and EventBridge."""
    event = event or {}
    params = {}

    # API Gateway query string
    params.update(event.get("queryStringParameters") or {})

    # API Gateway JSON body
    body = event.get("body")
    if body:
        try:
            params.update(json.loads(body) if isinstance(body, str) else body)
        except (ValueError, TypeError):
            pass

    # Direct invocation / EventBridge input: {"branch": "...", "workflow": "..."}
    for key in ("branch", "workflow"):
        if event.get(key):
            params[key] = event[key]

    return params.get("branch"), params.get("workflow")


def lambda_handler(event, context):
    try:
        branch, workflow = _extract_params(event)

        if not branch or not workflow:
            raise ValueError("'workflow' and 'branch' are required parameters")

        logger.info("Triggering workflow=%s on branch=%s", workflow, branch)
        GitHubOps.run_workflow(branch, workflow)
        logger.info("Execution Completed")

        return _response(200, f"Workflow {workflow} triggered on branch {branch}")

    except ValueError as e:
        logger.error(e)
        return _response(400, str(e))
    except Exception as e:
        logger.exception("Workflow execution failed")
        return _response(500, str(e))
